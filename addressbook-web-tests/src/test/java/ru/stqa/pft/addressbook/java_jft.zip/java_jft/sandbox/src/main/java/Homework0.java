public class Homework0 {
    public static void main(String[] args) {
        System.out.println("Домашняя работа 0");
    }
}
